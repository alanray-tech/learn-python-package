# hello-cpp

Minimal C++ hello world module exported with pybind11 and built via CMake.

```python
import hello_cpp

print(hello_cpp.hello())
```
